<?php
require_once "includes/presets.php";

header("Location: Dashboard.php");